"""{{ cookiecutter.package_name }} - {{ cookiecutter.package_description }}"""

# __version__ = "1.0"
# __author__ = "narutolavo"
# __all__ = []

